# crm/forms.py
from django import forms
from .models import Customer, Communication

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = '__all__'

class CommunicationForm(forms.ModelForm):
    class Meta:
        model = Communication
        fields = ['customer', 'note']
