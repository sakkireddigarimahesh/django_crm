# crm/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Customer, Communication
from .forms import CustomerForm, CommunicationForm

def dashboard(request):
    customers = Customer.objects.all()
    return render(request, 'crm/dashboard.html', {'customers': customers})

def add_customer(request):
    form = CustomerForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('dashboard')
    return render(request, 'crm/customer_form.html', {'form': form})

def update_customer(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    form = CustomerForm(request.POST or None, instance=customer)
    if form.is_valid():
        form.save()
        return redirect('dashboard')
    return render(request, 'crm/customer_form.html', {'form': form})

def delete_customer(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        customer.delete()
        return redirect('dashboard')
    return render(request, 'crm/delete_confirm.html', {'customer': customer})
